#define NBPW sizeof(int)
#define NBBY 8
#define NOFILE 10

#include "fsizemain.c"

#include "fsize.c"
#include "dirwalk.c"

#include "opendir.c"
#include "readdir.c"
#include "closedir.c"
