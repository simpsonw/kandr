int  x = 1;
char squote = '\'';
long day = 1000L * 60L * 60L * 24L;  /* milliseconds/day */
