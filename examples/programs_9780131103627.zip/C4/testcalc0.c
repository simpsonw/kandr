  #pragma linkage C
#include "calc0.c"
  #pragma linkage
#include "getline.c"
#include "getch.c"
#include "ungetch.c"
