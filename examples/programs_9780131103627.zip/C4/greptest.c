#include "grepmain.c"

#include "getline.c"
#include "getch.c"
#include "ungetch.c"

#include "strindex.c"
