#include <stdio.h>
#include <string.h>
#include "fgetline.c"

main()
{
	int day, month, year;
	char monthname[10];
	char line[100];

#include "date.c"

	return 0;
}
