printf("%.*s", max, s);
