#define frand() ((double) rand() / (RAND_MAX+1.0))
