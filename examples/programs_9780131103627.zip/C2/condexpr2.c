printf("You have %d item%s.\n", n, n==1 ? "" : "s");
