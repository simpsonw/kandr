/* srand:  set seed for rand() */
void srand(unsigned int seed)
{
	next = seed;
}
