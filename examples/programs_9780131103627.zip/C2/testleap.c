#include <stdio.h>

main()
{
	int year;

	while (scanf("%d", &year) != EOF)

#include "leap.c"

	return 0;
}
