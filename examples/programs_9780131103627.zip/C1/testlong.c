#include "longmain.c"
#include "getline1.c"
#include "copyfcn1.c"
