#include <stdio.h>

main()
{
	printf("hello, ");
	printf("world");
	printf("\n");
}
