#include "longline2.h"
#include "longmain2.c"
#include "getline2.c"
#include "copyfcn2.c"
