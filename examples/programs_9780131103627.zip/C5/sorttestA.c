
#include "sortmain.c"
#include <stdlib.h>
char *alloc(int n) { return (char *) malloc(n); }
#include "readlines.c"
#include "writelines2.c"

#include "qsort.c"
#include "qswap.c"

#include "getline.c"
