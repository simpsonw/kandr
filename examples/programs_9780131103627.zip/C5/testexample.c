#include <stdio.h>

void f() {
#include "example1.c"
}
