#include <stdio.h>
#include "strstr.c"
#include "find.c"
#include "getline.c"
#include "getch.c"
