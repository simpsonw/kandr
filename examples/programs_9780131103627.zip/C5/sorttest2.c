
#include "sortmain2.c"
#include <stdlib.h>
char *alloc(int n) { return (char *) malloc(n); }
#include "readlines.c"
#include "writelines.c"

#include "qsort2.c"
#include "qswap2.c"
#include "numcmp.c"

#include "getline.c"
