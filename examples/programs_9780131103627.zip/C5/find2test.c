#include <stdio.h>
#include "strstr.c"
#include "find2.c"
#include "getline.c"
#include "getch.c"
