#include "keystruct.c"
#define  NKEYS  (sizeof(keytab) / sizeof(struct key))
#include "keymain2.c"
#include "keybinary3.c"

#include "getch.c"
#include "ungetch.c"

#include "getword.c"
