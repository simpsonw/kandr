Treeptr talloc(void)
{
	return (Treeptr) malloc(sizeof(Treenode));
}
