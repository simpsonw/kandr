#include "tnode.h"
#include "freqmain.c"

#include "addtree.c"
#include "treeprint.c"
#include "talloc.c"

#include "getch.c"
#include "ungetch.c"
#include "getword.c"
#include "strdup.c"
