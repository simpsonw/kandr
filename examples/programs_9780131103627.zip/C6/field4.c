if (flags.is_extern == 0 && flags.is_static == 0)
