PFI strcmp, numcmp;
