struct rect {
    struct point pt1;
    struct point pt2;
};
