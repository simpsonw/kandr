#include "field1.c"


main()
{

#include "field2.c"
#include "field3.c"
#include "field4.c"
	flags.is_static = 0;

	return 0;
}
