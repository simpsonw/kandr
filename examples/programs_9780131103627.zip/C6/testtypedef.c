#include <stdio.h>
#include <stdlib.h>

#include "typedef.c"
#include "talloc1.c"

#include "typedef2.c"
#include "typedef3.c"
