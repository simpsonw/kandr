typedef int (*PFI)(char *, char *);
