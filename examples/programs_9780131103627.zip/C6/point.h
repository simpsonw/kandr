struct point {
    int x;
    int y;
};
