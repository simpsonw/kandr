flags.is_extern = flags.is_static = 1;
