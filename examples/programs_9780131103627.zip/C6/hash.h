#define HASHSIZE 101

static struct nlist *hashtab[HASHSIZE];	/* pointer table */
