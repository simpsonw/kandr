printf("origin is (%d,%d)\n", pp->x, pp->y);
